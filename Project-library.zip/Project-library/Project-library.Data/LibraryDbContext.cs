﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Project_library.Data.Models;
using System.Linq;


namespace Project_library.Data
{
    public class LibraryDbContext : DbContext
    {

        public LibraryDbContext(DbContextOptions<LibraryDbContext> options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
            { optionsBuilder.UseSqlServer(ConfigurationData.ConnectionString); }
            base.OnConfiguring(optionsBuilder);
        }
        
       public DbSet<Transport> Transports { get; set; }
        public DbSet<Unit> Units { get; set; }
        public DbSet<Title> Titles { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
