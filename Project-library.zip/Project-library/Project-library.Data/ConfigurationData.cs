﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.Data
{
   public static class ConfigurationData
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS; Database= LibrarySystem; Integrated Security=true;";
    }
}
