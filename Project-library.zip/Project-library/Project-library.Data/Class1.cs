﻿using System;

namespace Project_library.Data
{
    public class Class1
    {
    }
}
