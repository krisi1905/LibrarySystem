﻿using System;

namespace Project_library.View.Models
{
    public class Class1
    {
    }
}
