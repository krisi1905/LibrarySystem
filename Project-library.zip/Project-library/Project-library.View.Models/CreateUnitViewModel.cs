﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.View.Models
{
   public class CreateUnitViewModel
    {
        public string Condition { get; set; }
        public string Career { get; set; } 
        public string Storage { get; set; }
    }
}
