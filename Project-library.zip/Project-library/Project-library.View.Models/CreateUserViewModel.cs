﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.View.Models
{
   public class CreateUserViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public string Names { get; set; }
    }
}
