﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.View.Models
{
   public class CreateTransportViewModel
    {
        public string Type { get; set; }
        public string Reader { get; set; }
        public string Librarian { get; set; }
        public string Condition { get; set; }

    }
}
