﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Project_library.Data.Models
{
   public class Unit
    {
        [Key]
        public int Id { get; set; }
        public int TitleId { get; set; }
        public Title Title { get; set; }
        public string Condition { get; set; }
        public string Career { get; set; } //*Carrier
        public string Storage { get; set; }
        public Unit() { }
    }
}
