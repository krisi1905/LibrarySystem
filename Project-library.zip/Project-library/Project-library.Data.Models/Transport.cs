﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.Data.Models
{
   public class Transport
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public DateTime Return { get; set; }
        public string Type { get; set; }
        public string Reader { get; set; }
        public string Librarian { get; set; }
        public string Condition { get; set; }
        public int UnitId { get; set; }
        public Unit Unit { get; set; }
        public Transport()
        {
            this.Date = DateTime.UtcNow;
            this.Return = DateTime.UtcNow;
        }
    }
}
