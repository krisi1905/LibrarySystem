﻿using System;

namespace Project_library.Data.Models
{
    public class Class1
    {
    }
}
