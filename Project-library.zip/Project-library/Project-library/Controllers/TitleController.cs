﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Project_library.Services.Interfaces;

namespace Project_library.Controllers
{
    public class TitleController:Controller
    {
        private ITitleService service;
        public TitleController(ITitleService service)
        {
            this.service = service;
        }
            [HttpGet]
            public IActionResult View()
        {
            return this.View();
        }
        [HttpPost]
        public IActionResult Create(string name, string description, string author, string isbn, string type, string image, string publisher, string section)
        {
            this.service.AddTitle(name, description, author,isbn,type,image,publisher,section);
            return this.RedirectToAction("Index", "Home");
        }


    }
}
