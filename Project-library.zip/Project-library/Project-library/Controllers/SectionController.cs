﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Project_library.Services.Interfaces;

namespace Project_library.Controllers
{
    public class SectionController:Controller
    {
        private ISectionService service;
        public SectionController(ISectionService service) { this.service = service; }
        [HttpGet]
        public IActionResult View() 
        {
            return this.View();
        }
        [HttpPost]
        public IActionResult Create(string name,string description)
        {
            this.service.CreateSection(name,description);
            return this.RedirectToAction("Index", "Home");
        }



    }
}
