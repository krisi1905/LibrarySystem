﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Project_library.Services;
using Project_library.Services.Interfaces;

namespace Project_library.Controllers
{
    public class TransportController:Controller
    {
        private ITransportService service;
        public TransportController(ITransportService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult View()  //.cshtml
        {
            return this.View();
        }
        [HttpPost]
        public IActionResult Create(string type, string reader, string librarian, string condition, string unit)
        {
            this.service.CreateTransport(type,reader,librarian, condition, unit);
            return this.RedirectToAction("Index", "Home");
        }

    }
}
