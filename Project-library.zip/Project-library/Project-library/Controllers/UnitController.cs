﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Project_library.Services.Interfaces;

namespace Project_library.Controllers
{
    public class UnitController : Controller
    {


        private IUnitService service;
        public UnitController(IUnitService service)
        {
            this.service = service;
        }
        [HttpGet]

        public IActionResult View()
        {
            return this.View();
        }

        
    }
}


