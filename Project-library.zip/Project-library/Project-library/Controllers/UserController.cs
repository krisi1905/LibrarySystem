﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Project_library.Services.Interfaces;

namespace Project_library.Controllers
{
    public class UserController:Controller
    {
        private IUserService service;
        public UserController(IUserService service)
        {
            this.service = service;
        }
        [HttpGet]

        public IActionResult Create()
        {
            return this.View();
        }

    }
}
