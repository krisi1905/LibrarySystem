﻿using System;
using System.Collections.Generic;
using System.Text;
using Project_library.Services.Interfaces;
using Project_library.Data;
using Project_library.Data.Models;

namespace Project_library.Services
{
    public class TitleService : ITitleService
    {
        private LibraryDbContext context;

        public TitleService(LibraryDbContext context)
        {
            this.context = context;
        }
        public int AddTitle(string name, string description, string author, string isbn, string type, string image, string publisher, string section)
        {
            var title = new Title()
            {
                Name = name,
                Description = description,
                Author = author,
                ISBN = isbn,
                Type = type,
                Image = image,
                Publisher = publisher
            };
            context.Titles.Add(title);
            context.SaveChanges();
            return title.Id;
        }
    }
}
