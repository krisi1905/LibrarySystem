﻿using System;
using System.Collections.Generic;
using System.Text;
using Project_library.Services.Interfaces;
using Project_library.Data;
using Project_library.Data.Models;


namespace Project_library.Services
{
   public class SectionService:ISectionService
    {
        private LibraryDbContext context;

        public SectionService(LibraryDbContext context)
        {
            this.context = context;
        }
        public int CreateSection(string name, string description)
        {
            var section = new Section()
            {
                Name=name,
                Description=description
            };
            context.Sections.Add(section);
            context.SaveChanges();
            return section.Id;
        }
    }
}
