﻿using System;
using System.Collections.Generic;
using System.Text;
using Project_library.Services.Interfaces;
using Project_library.Data;
using Project_library.Data.Models;

namespace Project_library.Services
{
    public class UserService : IUserService
    {
        private LibraryDbContext context;

        public UserService(LibraryDbContext context)
        {
            this.context = context;
        }
        public int AddUser(string username, string password, string role, string email, string names)
        {
            var user = new User()
            {
                Username = username,
                Password = password,
                Role = role,
                Email = email,
                Names = names
            };
            context.Users.Add(user);
            context.SaveChanges();
            return user.UserId;







        }
    }
}
