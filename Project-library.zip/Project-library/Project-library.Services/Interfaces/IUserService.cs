﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.Services.Interfaces
{
   public interface IUserService
    {
        public int AddUser(string username, string password, string role, string email, string names);
    }
}
