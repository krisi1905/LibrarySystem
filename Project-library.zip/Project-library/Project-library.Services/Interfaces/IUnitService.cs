﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.Services.Interfaces
{
    public interface IUnitService
    {
        public int CreateUnit(string condition, string carrer, string storage, string title);
    }
}
