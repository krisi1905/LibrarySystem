﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.Services.Interfaces
{
   public interface ITransportService
    {
        public int CreateTransport(string type, string reader, string librarian, string condition, string unit);
 
    }
}
