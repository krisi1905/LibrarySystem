﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project_library.Services.Interfaces
{
   public interface ISectionService
    {
        public int CreateSection(string name, string description);
        
    }
}
