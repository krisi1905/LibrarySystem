﻿using System;
using System.Collections.Generic;
using System.Text;
using Project_library.Services.Interfaces;
using Project_library.Data;
using Project_library.Data.Models;

namespace Project_library.Services
{
   public class TransportService:ITransportService
    {
        private LibraryDbContext context;

        public TransportService(LibraryDbContext context)
        {
            this.context = context;
        }
        public int CreateTransport(string type,string reader, string librarian, string unit,string condition)
        {
            var transport = new Transport() 
            { 
                Type = type,
                Reader=reader,
                Librarian=librarian,
                Condition=condition
            };
            context.Transports.Add(transport);
            context.SaveChanges();
            return transport.Id;
        }









    }
}
