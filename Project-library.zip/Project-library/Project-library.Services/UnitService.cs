﻿using System;
using System.Collections.Generic;
using System.Text;
using Project_library.Services.Interfaces;
using Project_library.Data;
using Project_library.Data.Models;

namespace Project_library.Services
{
    public class UnitService : IUnitService
    {
        private LibraryDbContext context;

        public UnitService(LibraryDbContext context)
        {
            this.context = context;
        }
        public int CreateUnit(string condition, string carrer, string storage, string title)
        {
            var unit = new Unit()
            {
                Condition = condition,
                Career = carrer,
                Storage = storage
            };
            context.Units.Add(unit);
            context.SaveChanges();
            return unit.Id;






        }
    }
}
